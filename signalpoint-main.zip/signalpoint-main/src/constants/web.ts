export const DOMAIN = "https://signalpoints.com";
export const CONTACT_EMAIL = "support@signal-points.com"

